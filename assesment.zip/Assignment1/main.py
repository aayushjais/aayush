from Employee import employee
import re

def listEmployee():
        g = (_.split(',') for _ in open("input.txt"))
        emp = []
        for l in g:
            emp.append(employee(l[0], l[1].rstrip()))
        [print(_) for _ in emp]

def validateEmail(email):                  # funcn to check valid mailid
    if (re.search(r'[a-zA-Z0-9.-]+@[a-z.]+(com)',email)):
        print("Valid email")
    else:
        print("Invalid email")


def checkInfoPresent(email):                # funcn to check mail-id is present or not
    d={}
    with open('input.txt') as f:
        for line in f:
            (k, d[k]) = line.split(',')[0].strip(), line.split(',')[1].strip()
    for (k,v) in d.items():
        k = k.strip()
        if email in d.keys():
            print("Welcome to Hurray")
            return d
        else:
            print("Sorry User is not Registered Yet.")
            break

def get_menu():                                       # funcn for choice selection
    print("\nMenu\nWELCOME TO HURREYTECH VENTURES PVT LTD.\n")
    while True:
        print("\n1. Login To Hurrey\n2. Create New Account\n3. Find Account Password\n4. Exit")
        choice1= input(">>> ")
        choice1 = int(choice1)
        print(type(choice1))
        if choice1 == 1:
            print("Logging in to Hurrey")
            email=input("Enter email :")
            validateEmail(email)
            pwd=input("Enter Password :")
            checkInfoPresent(email)
            listEmployee()
        elif choice1 == 2:
            print("Create new account ")
            email = input("Enter email :")
            validateEmail(email)
            pwd = input("Enter Password :")
            new_emp = employee(email,pwd)
            with open('input.txt','a') as fin:
                fin.write(email +"," +pwd+"\n")
        elif choice1 == 3:
            print("Find Account Pwd ")
            email = input("Enter email :")
            validateEmail(email)
            d=checkInfoPresent(email)
            if d:
                print('Your Password is:***',d[email][-3:])
        elif choice1 ==4:
            print("Thanks for using. Closing the system.")
            break
        else:
            print("please enter valid choice.")

while True:
    print("\nMenu\n(Y)Do You want to continue\n(Q)uit")
    choice = input(">>> ").lower().rstrip()
    if choice == 'q':
        break
    elif choice =='y':
        get_menu()
    else:
        print("Invalid choice, please choose again\n")




