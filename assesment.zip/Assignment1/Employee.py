class employee:
        def __init__(self, email, password):
            self. email = email
            self. password = password

        def __str__(self):
            return f"Employee email = {self.email} Password = {self.password}"